#' testSpinner
#' @export
testSpinner <- function(...) {
  withSpinner(..., hide.ui = FALSE)
}
