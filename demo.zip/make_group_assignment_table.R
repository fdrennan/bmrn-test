#' #' make_group_assignment_table
#' #' @export
#' make_group_assignment_table <- function(data, type_names, ns) {
#'
#' }
